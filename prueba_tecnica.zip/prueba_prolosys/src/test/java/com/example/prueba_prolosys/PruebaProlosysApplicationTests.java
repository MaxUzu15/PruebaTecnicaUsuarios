package com.example.prueba_prolosys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaProlosysApplicationTests {

	@Test
	void contextLoads() {
	}

}
