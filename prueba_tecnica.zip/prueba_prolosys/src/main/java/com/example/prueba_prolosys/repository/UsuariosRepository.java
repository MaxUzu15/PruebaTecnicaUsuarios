package com.example.prueba_prolosys.repository;

import com.example.prueba_prolosys.entity.Usuarios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuariosRepository extends JpaRepository<Usuarios,Long> {

    @Query(value = "FROM Usuarios u where u.noEmpleado = :noEmpleado")
    Optional<Usuarios> findUsuarioByNoEmpleado (@Param("noEmpleado") String noEmpleado);

    @Query(value = "FROM Usuarios u ORDER BY u.noEmpleado DESC LIMIT 1")
    List<Usuarios> findLastUsuario ();
}
