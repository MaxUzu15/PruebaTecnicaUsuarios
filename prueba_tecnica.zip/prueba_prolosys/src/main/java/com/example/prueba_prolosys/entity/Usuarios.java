package com.example.prueba_prolosys.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity  // Marca esta clase como una entidad JPA.
@Table(name= "USUARIOS")
public class Usuarios implements Serializable {

    @Column(name = "NOMBRE")
    private String nombre;

    @Column(name = "APELLIDO_PATERNO")
    private String apellidoPaterno;

    @Column(name = "APELLIDO_MATERNO")
    private String apellidoMaterno;

    @Id
    @Column(name = "NO_EMPLEADO")
    private String noEmpleado;

    @Column(name = "EMPRESA")
    private String empresa;

    @Column(name = "SEXO")
    private String sexo;

    @Column(name = "FECHA_NACIMIENTO")
    private Date fechaNacimiento;

    @Column(name = "CURP")
    private String curp;

    @Column(name = "RFC")
    private String rfc;
}
