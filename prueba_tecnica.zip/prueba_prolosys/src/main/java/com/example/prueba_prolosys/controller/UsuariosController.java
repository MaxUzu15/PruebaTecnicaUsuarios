package com.example.prueba_prolosys.controller;

import com.example.prueba_prolosys.dto.UsuarioDTO;
import com.example.prueba_prolosys.service.IUsuariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pruebaTecnica/usuarios")
@CrossOrigin(origins = "http://localhost:4200")
public class UsuariosController {
    @Autowired
    IUsuariosService iUsuariosService;

    @PostMapping("/crear")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<String> crearUsuario(@RequestBody UsuarioDTO usuarioDTO) {
        try {
            String estatusUsuario = iUsuariosService.crearUsuario(usuarioDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(estatusUsuario);
        }catch (Exception e) {
            return  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al crear el usuario: "+e.getMessage());
        }
    }

    @GetMapping("/consulta")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<List<UsuarioDTO>> crearReporte() {
        try {
            List<UsuarioDTO> reservaDTO = iUsuariosService.consultarUsuarios();
            return ResponseEntity.ok(reservaDTO);
        }catch (Exception e) {
            return  ResponseEntity.notFound().build();
        }

    }

    @PutMapping("/actualizar")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<String> actualizarReserva(@RequestBody UsuarioDTO usuario) {
        try {
            String estatusUsuario = iUsuariosService.actualizarUsuario(usuario);
            return ResponseEntity.status(HttpStatus.CREATED).body(estatusUsuario);
        }catch (Exception e) {
            return  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al actulizar el usuario: "+e.getMessage());
        }
    }

    @DeleteMapping("/eliminar/{noEmpleado}")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<String> eliminarReserva(@PathVariable String noEmpleado) {
        try {
            String estatusUsuario = iUsuariosService.eliminarUsuario(noEmpleado);
            return ResponseEntity.status(HttpStatus.CREATED).body(estatusUsuario);
        }catch (Exception e) {
            return  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al eliminar el usuario: "+e.getMessage());
        }
    }
}
