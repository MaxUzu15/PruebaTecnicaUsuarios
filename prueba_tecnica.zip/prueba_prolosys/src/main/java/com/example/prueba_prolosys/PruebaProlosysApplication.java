package com.example.prueba_prolosys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaProlosysApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaProlosysApplication.class, args);
	}

}
