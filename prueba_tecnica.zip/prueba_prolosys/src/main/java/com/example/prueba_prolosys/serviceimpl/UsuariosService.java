package com.example.prueba_prolosys.serviceimpl;

import com.example.prueba_prolosys.Constants;
import com.example.prueba_prolosys.dto.UsuarioDTO;
import com.example.prueba_prolosys.entity.Usuarios;
import com.example.prueba_prolosys.repository.UsuariosRepository;
import com.example.prueba_prolosys.service.IUsuariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class UsuariosService implements IUsuariosService {

    @Autowired
    UsuariosRepository usuariosRepository;

    public String crearUsuario (UsuarioDTO usuarioDTO){
        String resultado = "Usuario Creado.";
        try{
            String noEmpleado ="E0000";
            List<Usuarios> allUsuers = usuariosRepository.findLastUsuario();
            if(allUsuers!= null && allUsuers.size() >0){
                int consecutivo = Integer.parseInt(allUsuers.get(0).getNoEmpleado().substring(1)) + 10;
                noEmpleado = "E" + String.format("%04d", consecutivo);
            }

            Optional<Usuarios> usuario =  usuariosRepository.findUsuarioByNoEmpleado(noEmpleado);
            if (usuario.isPresent()) {
                resultado = "Este numero de empleado ya ha sido registrado previamente";
            }else{
                Usuarios nuevoUsuario = new Usuarios();
                nuevoUsuario.setNombre(usuarioDTO.getNombre());
                nuevoUsuario.setApellidoPaterno(usuarioDTO.getApellidoPaterno());
                nuevoUsuario.setApellidoMaterno(usuarioDTO.getApellidoMaterno());
                nuevoUsuario.setNoEmpleado(noEmpleado);
                nuevoUsuario.setEmpresa(usuarioDTO.getEmpresa());
                nuevoUsuario.setSexo(usuarioDTO.getSexo());

                SimpleDateFormat formatter = new SimpleDateFormat(Constants.FORMAT_DATE_GENERAL);
                Date date =formatter.parse(usuarioDTO.getFechaNacimiento());
                nuevoUsuario.setFechaNacimiento(date);

                nuevoUsuario.setCurp(usuarioDTO.getCurp());
                nuevoUsuario.setRfc(usuarioDTO.getRfc());

                usuariosRepository.save(nuevoUsuario);
            }
        }catch (Exception e){
            return "Ocurrió un error al crear el usuario: " + e.getMessage();
        }

        return resultado;
    }

    public List<UsuarioDTO> consultarUsuarios(){
        List<UsuarioDTO> consultaUsuarios = new ArrayList<>();
        try {
            List<Usuarios> usuariosTotales = usuariosRepository.findAll();
            if(usuariosTotales != null && usuariosTotales.size() > 0){
                for(Usuarios usuario: usuariosTotales){
                    UsuarioDTO usuarioDTO =  new UsuarioDTO();
                    usuarioDTO.setNombre(usuario.getNombre());
                    usuarioDTO.setApellidoPaterno(usuario.getApellidoPaterno());
                    usuarioDTO.setApellidoMaterno(usuario.getApellidoMaterno());
                    usuarioDTO.setNoEmpleado(usuario.getNoEmpleado());
                    usuarioDTO.setEmpresa(usuario.getEmpresa());
                    usuarioDTO.setSexo(usuario.getSexo());

                    DateFormat df = new SimpleDateFormat(Constants.FORMAT_DATE_GENERAL);
                    usuarioDTO.setFechaNacimiento(df.format(usuario.getFechaNacimiento()));
                    usuarioDTO.setCurp(usuario.getCurp());
                    usuarioDTO.setRfc(usuario.getRfc());

                    consultaUsuarios.add(usuarioDTO);
                }
                return consultaUsuarios;
            }
        }catch (Exception e){
            System.out.println("Ocurrio un error al obtener los usuarios: " + e.getMessage());
        }
        return null;
    }

    public String actualizarUsuario(UsuarioDTO usuarioDTO){
        String resultado = "Usuario Actualizado.";
        try {
            Optional<Usuarios> usuarioExiste =  usuariosRepository.findUsuarioByNoEmpleado(usuarioDTO.getNoEmpleado());
            if (usuarioExiste.isPresent()) {
                Usuarios usuario = usuarioExiste.get();
                usuario.setNombre(usuarioDTO.getNombre());
                usuario.setApellidoPaterno(usuarioDTO.getApellidoPaterno());
                usuario.setApellidoMaterno(usuarioDTO.getApellidoMaterno());
                usuario.setEmpresa(usuarioDTO.getEmpresa());
                usuario.setSexo(usuarioDTO.getSexo());

                SimpleDateFormat formatter = new SimpleDateFormat(Constants.FORMAT_DATE_GENERAL);
                Date date =formatter.parse(usuarioDTO.getFechaNacimiento());
                usuario.setFechaNacimiento(date);

                usuario.setCurp(usuarioDTO.getCurp());
                usuario.setRfc(usuarioDTO.getRfc());

                usuariosRepository.save(usuario);
            }else{
                resultado = "Este numero de empleado no existe";
            }
        }catch (Exception e){
            return "Ocurrió un error al actualizar el usuario: " + e.getMessage();
        }
        return resultado;
    }

    public String eliminarUsuario(String noEmpleado){
        String resultado = "Usuario Eliminado.";
        try {
            Optional<Usuarios> usuarioExiste =  usuariosRepository.findUsuarioByNoEmpleado(noEmpleado);
            if(usuarioExiste.isPresent()){
                usuariosRepository.delete(usuarioExiste.get());
            }else{
                resultado = "Este numero de empleado no existe";
            }
        }catch (Exception e){
            return "Ocurrió un error al eliminar el usuario: " + e.getMessage();
        }
        return resultado;
    }
}
