package com.example.prueba_prolosys.service;

import com.example.prueba_prolosys.dto.UsuarioDTO;

import java.util.List;

public interface IUsuariosService {

    public String crearUsuario (UsuarioDTO usuarioDTO);

    public List<UsuarioDTO> consultarUsuarios();

    public String actualizarUsuario(UsuarioDTO usuarioDTO);

    public String eliminarUsuario(String noEmpleado);
}
