package com.example.prueba_prolosys.dto;

import com.example.prueba_prolosys.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsuarioDTO implements Serializable {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String noEmpleado;
    private String empresa;
    private String sexo;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = Constants.FORMAT_DATE_GENERAL,timezone = Constants.TIME_ZONE_MEXICO)
    private String fechaNacimiento;
    private String curp;
    private String rfc;
}
