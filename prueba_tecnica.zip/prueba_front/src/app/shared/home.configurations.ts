export const BASE_URL_BACKEND = 'http://localhost:8080/pruebaTecnica/usuarios';
export const CONSULTA_USUARIOS = '/consulta';
export const ACTUALIZA_USUARIOS = '/actualizar';
export const ELIMINA_USUARIOS = '/eliminar/';
export const CREA_USUARIOS = '/crear';
export const BASE_URL_BACKEND_POST = 'http://localhost:8080/pruebaTecnica/usuarios';
