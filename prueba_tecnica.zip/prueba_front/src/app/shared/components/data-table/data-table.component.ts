import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit,ViewChild } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { Injectable } from '@angular/core';
import {Subscription} from 'rxjs'
import {BASE_URL_BACKEND,CONSULTA_USUARIOS,BASE_URL_BACKEND_POST,ACTUALIZA_USUARIOS,ELIMINA_USUARIOS,CREA_USUARIOS} from '../../home.configurations';
import { UsuariosComponent } from '../../../views/usuarios/usuarios.component';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-data-table',
  standalone: false, 
  templateUrl: './data-table.component.html',
  styleUrl: './data-table.component.css'
})
@Injectable({
  providedIn: 'root'
})
export class DataTableComponent implements OnInit{

  @ViewChild(MatTable) tabla1!: MatTable<Usuario>;
  constructor(private http: HttpClient,private cdRef: ChangeDetectorRef,private datePipe: DatePipe){
    this.dataSource = new MatTableDataSource(this.datos);
  }
  ngOnInit(): void {

  }
  columnas: string[] = ['nombre', 'apellidoPaterno', 'apellidoMaterno', 'noEmpleado', 'empresa','sexo','fechaNacimiento','curp','rfc','editar','borrar'];
  datos: Usuario[] = [];
  dataSource = new MatTableDataSource<Usuario>();

  tablaVisible:boolean = false;
  formVisible: boolean = false;
  filterVisible:boolean = false;
    iniciarTabla(data:any[],isTableVisible:boolean, isFormVisible: boolean,isFilterVisible:boolean){
      this.formVisible = isFormVisible;
      this.tablaVisible = isTableVisible;
      this.filterVisible = isFilterVisible;
      data.forEach(element => {
        this.datos.push(new Usuario(
          element.nombre,
          element.apellidoPaterno,
          element.apellidoMaterno,
          element.noEmpleado,
          element.empresa,
          element.sexo,
          element.fechaNacimiento,
          element.curp,
          element.rfc
        ));
      });
      //this.dataSource.sort = this.sort;
      this.dataSource = new MatTableDataSource(data);
      this.cdRef.detectChanges();
      
    }

    consultarUsuarios(){
      let url = BASE_URL_BACKEND + CONSULTA_USUARIOS;
      this.http.get<any>(url).subscribe({
        next: (data:any) =>{
          this.iniciarTabla(data,true,true,false);
        }
      });
    }

    borrar(data: any){
      if(confirm("¿Esta seguro que desea borrar este usuario?")){
      let url = BASE_URL_BACKEND + ELIMINA_USUARIOS + data.noEmpleado;
      this.http.delete<any>(url).subscribe({
        next: (response) =>{
          if (response.status === 200 || response.status === 201) { 
            console.log('Usuario eliminado con éxito:', response.body); // Aquí puedes agregar lógica adicional, como actualizar la vista }
          }
        }, 
        error: (err) => { 
          if(err.status === 201){
             console.log('Usuario eliminado con éxito');
             this.consultarUsuarios();
          }else{
            confirm(err.error.text);
            console.error('Error al eliminar el usuario:', err); 
          }
        },complete: () => { 
          this.consultarUsuarios();
        }
      });
    }
    }

    editarUsuario(data:any){
      if(confirm("¿Esta seguro que desea editar esta usuario?")){
      let url = BASE_URL_BACKEND + ACTUALIZA_USUARIOS;
      let usuarioActualizada = new Usuario(
        data.nombre,
        data.apellidoPaterno,
        data.apellidoMaterno,
        data.noEmpleado,
        data.empresa,
        data.sexo,
        data.fechaNacimiento,
        data.curp,
        data.rfc
      );
      this.http.put<any>(url,usuarioActualizada).subscribe({
        next: (response) => { 
          console.log('Usuario actualizado con éxito:', response); 
          this.consultarUsuarios();
         }, 
         error: (err) => { 
          if(err.status === 201 && err.error.text == 'Usuario actualizada.'){
              console.log('Usuario actualizado con éxito');
              this.consultarUsuarios();
          }else{
            confirm(err.error.text);
          console.error('Error al actualizar el usuario:', err); 
          }
        }, 
        complete: () => { 
          this.consultarUsuarios();
        }
      });
    }

    }
    usuarioNueva: Usuario = new Usuario("","","","","","","","","");
    crearUsuario(){
      this.usuarioNueva.fechaNacimiento = this.datePipe.transform(this.usuarioNueva.fechaNacimiento, 'dd/MM/yyyy') ?? '';
      let url = BASE_URL_BACKEND_POST + CREA_USUARIOS;
      this.http.post<any>(url,this.usuarioNueva).subscribe({
        next: (response) => { 
          console.log('Usuario creada con éxito:', response); 
          this.usuarioNueva  = new Usuario("","","","","","","","","");
          this.consultarUsuarios();
         }, 
         error: (err) => { 
          confirm(err.error.text);
          console.error('Error al actualizar la usuario:', err); 
          this.consultarUsuarios();
        }, 
        complete: () => { 
          this.consultarUsuarios();
        }
      });
    }
    reporteFiltro: Usuario = new Usuario("","","","","","","","","");
  
}


export class Usuario {
  constructor(
    public nombre: string, 
    public apellidoPaterno: string,
    public apellidoMaterno: string, 
    public noEmpleado: string,
    public empresa: string,
    public sexo: string,
    public fechaNacimiento: string,
    public curp: string,
    public rfc: string
    ) {
  }


}
