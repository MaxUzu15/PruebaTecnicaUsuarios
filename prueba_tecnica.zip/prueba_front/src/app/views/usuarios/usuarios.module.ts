import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsuariosRoutingModule } from './usuarios-routing.module';
import { UsuariosComponent } from './usuarios.component';
import { SharedModule } from "../../shared/shared.module";
import { HttpClient, HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [UsuariosComponent],
  imports: [
    CommonModule,
    UsuariosRoutingModule,
    SharedModule,
    HttpClientModule
]
})
export class UsuariosModule { }
