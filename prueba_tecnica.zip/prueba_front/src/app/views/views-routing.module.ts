import { NgModule } from "@angular/core";
import { RouterModule,Routes } from "@angular/router";
import { ViewsComponent } from "./views.component";


const routes: Routes = [{
    path: '', component: ViewsComponent,
    children:[
        {path: '', redirectTo: 'menu', pathMatch: 'full'},
        {path: 'usuarios',loadChildren: () => import('./usuarios/usuarios.module').then(child => child.UsuariosModule)},
        {path: 'menu',loadChildren: () => import('./menu/menu.module').then(child => child.MenuModule)}
    ]
   }]

   @NgModule({
    imports:[RouterModule.forChild(routes)],
    exports:[RouterModule]
   })
   export class ViewsRoutingModule{}